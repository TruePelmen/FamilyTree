global using Xunit;
global using FamilyTree.BLL.Interfaces;
global using FamilyTree.BLL.Services;
global using FamilyTree.BLL;
global using FamilyTree.DAL.Interfaces.Repositories;
global using FamilyTree.DAL.Models;
global using Moq;
global using FluentAssertions;